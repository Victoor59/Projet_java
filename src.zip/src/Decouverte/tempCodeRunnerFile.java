package Decouverte;



import java.util.Scanner;

public class tp1 {
    
    // Exercice 1
    public static void displayString() {
        System.out.println("Hello World");
    }

    // Exercice 2
    public static void displayVariable() {
        String var = "Hello World";
        System.out.println(var);
    }

    // Exercice 3
    public static void calculatePerimeter() {
        double radius = 5;
        double perimeter = 2 * Math.PI * radius;
        System.out.println("Perimeter is: " + perimeter);
    }

    // Exercice 4
    public static void calculatePerimeterFromInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter radius:");
        double radius = scanner.nextDouble();
        double perimeter = 2 * Math.PI * radius;
        System.out.println("Perimeter is: " + perimeter);
    }

    // Exercice 5
    public static void checkAge() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter age:");
        int age = scanner.nextInt();
        if (age < 18) {
            System.out.println("Minor");
        } else {
            System.out.println("Major");
        }
    }

    // Exercice 6
    public static void checkNumber() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number:");
        int number = scanner.nextInt();
        if (number % 2 == 0) {
            System.out.println("Even");
        } else {
            System.out.println("Odd");
        }
    }

    // Exercice 7
    public static void checkLeapYear() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter year:");
        int year = scanner.nextInt();
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            System.out.println("Leap Year");
        } else {
            System.out.println("Not a Leap Year");
        }
    }

    // Exercice 8
    public static void checkDaysInMonth() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter month number:");
        int month = scanner.nextInt();
        int days;
        switch (month) {
            case 2:
                days = 28; 
                break;
            case 4: case 6: case 9: case 11:
                days = 30;
                break;
            default:
                days = 31;
        }
        System.out.println("Number of days: " + days);
    }

    // Exercice 8 Bis
    public static void checkDaysInMonthString() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter month name:");
        String month = scanner.nextLine().toLowerCase();
        int days;

        switch (month) {
            case "february":
                days = 28; 
                break;
            case "april":
            case "june":
            case "september":
            case "november":
                days = 30;
                break;
            default:
                days = 31;
        }
        System.out.println("Number of days: " + days);
    }

    // Exercice 8 Ter
    private static boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
    
    public static void checkLeapYearFunction() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter year:");
        int year = scanner.nextInt();
        if (isLeapYear(year)) {
            System.out.println("Leap Year");
        } else {
            System.out.println("Not a Leap Year");
        }
    }

    // Exercice 9
    public static void printNumbers() {
        for (int i = 1; i <= 100; i++) {
            System.out.println(i);
        }
    }

    // Exercice 11
    public static void printCharCodes() {
        for (int i = 1; i <= 255; i++) {
            System.out.println("Number: " + i + ", Char: " + (char) i);
        }
    }

    // Exercice 12
    public static void swapValues() {
        int a = 5;
        int b = 10;
        System.out.println("Before swap: a = " + a + ", b = " + b);
        int temp = a;
        a = b;
        b = temp;
   
    System.out.println("After swap: a = " + a + ", b = " + b);
    }

    public static void main(String[] args) {
        displayString();
        displayVariable();
        calculatePerimeter();
        calculatePerimeterFromInput();
        checkAge();
        checkNumber();
        checkLeapYear();
        checkDaysInMonth();
        checkDaysInMonthString();
        checkLeapYearFunction();
        printNumbers();
        printCharCodes();
        swapValues();
    }
}



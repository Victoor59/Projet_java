public class tp3 {
    // Classe Animal
    static class Animal {
            public void cri() {
                System.out.println("Ceci est un cri d'animal générique.");
            }
            
            @Override
            public String toString() {
                return "C'est un animal.";
            }
        }
        
        public class Chat extends Animal {
            @Override
            public void cri() {
                System.out.println("Miaou!");
            }
            
            @Override
            public String toString() {
                return "C'est un chat.";
            }
        }
        
        public class Chien extends Animal {
            public void aboyer() {
                System.out.println("Woof!");
            }
            
            @Override
            public void cri() {
                System.out.println("Woof woof!");
            }
            
            @Override
            public String toString() {
                return "C'est un chien.";
            }
        }
        


    // Classe Forme
   static class Forme {
        protected int x, y;
        
        public void creer() {
            // Ici, vous pouvez demander les informations à l'utilisateur
            // Mais pour simplifier, nous allons simplement assigner des valeurs.
            this.x = 100;
            this.y = 200;
        }
        
        public void afficher() {
            System.out.println("Forme à la position : (" + this.x + ", " + this.y + ")");
        }
        
        public void deplacer(int dx, int dy) {
            this.x += dx;
            this.y += dy;
        }
        
        public void verifier() {
            // Vérifiez que les coordonnées sont dans les limites
            if (this.x < 0 || this.x > 800 || this.y < 0 || this.y > 600) {
                System.out.println("La forme est hors limites.");
            } else {
                System.out.println("La forme est dans les limites.");
            }
        }
    }
    
    public class Rectangle extends Forme {
        private int largeur, hauteur;
        
        @Override
        public void creer() {
            super.creer();
            // De même, ici vous pouvez demander les informations à l'utilisateur.
            // Nous allons simplement assigner des valeurs.
            this.largeur = 50;
            this.hauteur = 100;
        }
        
        @Override
        public void afficher() {
            super.afficher();
            System.out.println("Largeur : " + this.largeur + ", Hauteur : " + this.hauteur);
        }
    }
    
       
    }


    // Classe Triangle
    public static class Triangle extends Forme {
        private int base;
        private int hauteur;
        private int cote1;
        private int cote2;
        
        public double calculerPerimetre() {
            return base + cote1 + cote2;
        }
        
        // Redéfinir ou ajouter des méthodes au besoin
    }

    // Interface IForme
    public interface IForme {
        public void creer();
        public void afficher();
        public void deplacer();
        public void verifier();
    }

    // Classe Point
    public static class Point {
        public int x;
        public int y;
    
        // Ajout d'un constructeur qui prend deux arguments
        public Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
        
        @Override
        public Point clone() {
            return new Point(this.x, this.y);
        }
    }

    // Classe Vehicule
    public abstract static class Vehicule {
        protected static int nextMatricule = 0;
        protected int matricule;
        protected String immatriculation;
        protected int annee;
        protected String modele;
        protected double prix;

        public Vehicule(String immatriculation, int annee, String modele, double prix) {
            this.matricule = nextMatricule++;
            this.immatriculation = immatriculation;
            this.annee = annee;
            this.modele = modele;
            this.prix = prix;
        }

        public void demarrer() {
            System.out.println(modele + " démarre");
        }

        public void accelerer() {
            System.out.println(modele + " accélère");
        }

        public void freiner() {
            System.out.println(modele + " freine");
        }

        public void arreter() {
            System.out.println(modele + " s'arrête");
        }
    }

    // Classe Voiture
    public static class Voiture extends Vehicule {
        public Voiture(String immatriculation, int annee, String modele, double prix) {
            super(immatriculation, annee, modele, prix);
        }
    }

    // Classe Camion
    public static class Camion extends Vehicule {
        public Camion(String immatriculation, int annee, String modele, double prix) {
            super(immatriculation, annee, modele, prix);
        }
    }

        public static void main(String[] args) {
            Chat chat = new Chat();
            chat.cri();
            Chien chien = new Chien();
            chien.cri();
            chien.aboyer();

             Rectangle rectangle = new Rectangle();
        rectangle.creer();
        rectangle.afficher();
        rectangle.deplacer(10, 20);
        rectangle.afficher();
        rectangle.verifier();

        }
}

public class tp2 {
    // Exercice 1
    public static void countCharacters(String str) {     
        Scanner scanner = new Scanner(System.in);
        System.out.print("Entrez une chaîne de caractères : ");
        String input = scanner.nextLine();
        scanner.close();

        int[] letterCount = new int[26]; // For alphabet letters

        input = input.toLowerCase(); // Convert to lowercase to ignore case

        countCharacters(input, letterCount);

        // Display the number of occurrences of each letter
        for (int i = 0; i < 26; i++) {
            if (letterCount[i] > 0) {
                char letter = (char) ('a' + i);
                System.out.println(letter + " : " + letterCount[i]);
            }
        }
    }

    public static void countCharacters(String input, int[] letterCount) {
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isLetter(c)) {
                int index = c - 'a'; // Calculate the index corresponding to the letter
                letterCount[index]++;
            }
        }
    }
    
    
    // Exercice 2
    public static void changeCase(String input) {
        System.out.println(input.toLowerCase());
        System.out.println(input.toUpperCase());
    }

    // Exercice 3
    public static void alternateCharacters(String input) {
        StringBuilder sb = new StringBuilder(input);
        for (int i = 1; i < sb.length(); i += 2) {
            sb.setCharAt(i, '*');
        }
        System.out.println(sb.toString());
    }

    // Exercice 4
    public static void bookDetails(String author, String title, String category, String isbn) {
        String code = author.substring(0, 2) + category.charAt(0) + isbn.substring(isbn.length() - 2);
        System.out.println("Author: " + author + ", Title: " + title + ", Category: " + category + ", ISBN: " + isbn + ", Code: " + code);
    }

    // Exercice 5
    public static void triangleOperations(double base, double height, double hypotenuse) {
        double perimeter = base + height + hypotenuse;
        double area = 0.5 * base * height;
        System.out.println("Perimeter: " + perimeter + ", Area: " + area);
    }

    // Exercice 6
    public static void mathOperations(double num1, double num2) {
        System.out.println("Addition: " + (num1 + num2));
        System.out.println("Subtraction: " + (num1 - num2));
        System.out.println("Multiplication: " + (num1 * num2));
        System.out.println("Division: " + (num1 / num2));
    }

 // Exercice 7
    public static void studentOperations(String firstName, String lastName, double[] scores) {      
        double sum = 0;
        for (double score : scores) {
            sum += score;
        }
        double average = sum / scores.length;
        String initials = firstName.charAt(0) + "." + lastName.charAt(0) + ".";
        String trigram = Character.toString(firstName.charAt(0)) + lastName.charAt(0) + lastName.charAt(lastName.length() - 1);
        System.out.println("Average: " + average + ", Initials: " + initials + ", Trigram: " + trigram);
    }

    // Exercice 8
    public static void carDetails(String make, String model, int year, String color) {
        System.out.println("Make: " + make + ", Model: " + model + ", Year: " + year + ", Color: " + color);
    }

    public static void main(String[] args) {
        countCharacters("Hello World!");
        changeCase("Hello World!");
        alternateCharacters("Hello World!");
        bookDetails("John Doe", "My Book", "Fiction", "1234567890");
        triangleOperations(3, 4, 5);
        mathOperations(10, 5);
        studentOperations("John", "Doe", new double[]{85.5, 90.5, 92.5});
        carDetails("Toyota", "Corolla", 2020, "Red");
    }
}
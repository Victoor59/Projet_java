/**
 * 
 */
/**
 * 
 */
module projet_final {
    requires java.sql;
    // Autres déclarations du module
}